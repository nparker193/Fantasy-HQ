const DEFAULT_LEAGUE = {
  id: "1381307935468032000",
  type: "redraft",
  label: "Deuce Deuce",
  myTeam: "RunCMC"
};
const STORE_KEY = "fantasy-hq-leagues-v1";
const PLAYER_CACHE_KEY = "fantasy-hq-player-directory-v1";
let leagues = loadSavedLeagues();
let activeLeagueId = leagues[0]?.id || "";
let activeData = null;
let selectedRosterId = null;

const $ = id => document.getElementById(id);
const fmt = n => Number(n || 0).toFixed(2);
function loadSavedLeagues() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORE_KEY) || "[]");
    if (saved.length) return saved;
  } catch {}
  return [{...DEFAULT_LEAGUE}];
}
function saveLeagues() { localStorage.setItem(STORE_KEY, JSON.stringify(leagues)); }
function toast(message) {
  const el = $("toast"); el.textContent = message; el.classList.add("show");
  clearTimeout(toast.timer); toast.timer = setTimeout(() => el.classList.remove("show"), 3200);
}
function points(settings = {}) {
  return Number(settings.fpts || 0) + Number(settings.fpts_decimal || 0) / 100;
}
function leagueUrl(id, path) { return `https://api.sleeper.app/v1/league/${encodeURIComponent(id)}/${path}`; }
async function getJson(url) {
  const response = await fetch(url);
  if (!response.ok) throw new Error(`Sleeper returned ${response.status} for ${url}`);
  return response.json();
}
async function getPlayerDirectory() {
  const cached = localStorage.getItem(PLAYER_CACHE_KEY);
  if (cached) {
    try {
      const parsed = JSON.parse(cached);
      if (Date.now() - parsed.savedAt < 24 * 60 * 60 * 1000) return parsed.players;
    } catch {}
  }
  const players = await getJson("https://api.sleeper.app/v1/players/nfl");
  try { localStorage.setItem(PLAYER_CACHE_KEY, JSON.stringify({savedAt: Date.now(), players})); }
  catch { console.warn("Player directory too large for localStorage; using in-memory copy."); }
  return players;
}
function playerInfo(id, directory) {
  const p = directory?.[id];
  return p ? {
    id, name: [p.first_name, p.last_name].filter(Boolean).join(" ") || p.full_name || id,
    position: p.position || "—", team: p.team || "FA"
  } : {id, name: `Player ${id}`, position: "—", team: "—"};
}
function rosterScore(r) { return points(r.settings); }
function renderSelect() {
  const select = $("leagueSelect");
  select.innerHTML = leagues.map(l => `<option value="${escapeHtml(l.id)}">${escapeHtml(l.label || l.id)} · ${l.type}</option>`).join("");
  select.value = activeLeagueId;
  $("refreshBtn").disabled = !activeLeagueId;
}
function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}
function setConnected(ok, text) {
  $("connectionStatus").classList.toggle("connected", ok);
  $("connectionStatus").innerHTML = `<i></i>${escapeHtml(text)}`;
}
function showTab(tab) {
  document.querySelectorAll(".tab").forEach(b => b.classList.toggle("active", b.dataset.tab === tab));
  document.querySelectorAll(".view").forEach(v => v.classList.toggle("active", v.id === `${tab}View`));
}
function playerRow(p, starter = false) {
  return `<div class="player-row"><div class="avatar">${escapeHtml(p.position)}</div><div><div class="player-name">${escapeHtml(p.name)}</div><div class="player-meta">${escapeHtml(p.team)} · ${starter ? "Starter" : "Roster"}</div></div><span class="player-tag">${escapeHtml(p.position)}</span></div>`;
}
function renderAll(data) {
  const mine = data.teams.find(t => t.isMine) || data.teams.find(t => t.roster.roster_id === data.rosters[0]?.roster_id);
  const r = mine?.roster;
  const myPlayers = mine?.players || [];
  $("teamHeading").textContent = mine ? mine.teamName : "Fantasy HQ";
  $("leagueSubheading").textContent = `${data.league.name || data.config.label} · ${data.config.type} · ${data.teams.length} teams`;
  $("recordStat").textContent = r ? `${r.settings.wins || 0}-${r.settings.losses || 0}` : "—";
  $("pointsStat").textContent = r ? fmt(rosterScore(r)) : "—";
  $("teamsStat").textContent = data.teams.length;
  $("rosterStat").textContent = myPlayers.length;
  const starterSet = new Set(r?.starters || []);
  const starters = myPlayers.filter(p => starterSet.has(p.id));
  $("rosterPreview").classList.remove("empty-state");
  $("rosterPreview").innerHTML = starters.length ? starters.slice(0, 7).map(p => playerRow(p, true)).join("") : `<p class="help">No starter information found for this roster.</p>`;
  $("myRoster").classList.remove("empty-state");
  $("myRoster").innerHTML = myPlayers.map(p => playerRow(p, starterSet.has(p.id))).join("") || "No players found.";
  $("rosterCount").textContent = `${myPlayers.length} players`;
  const sorted = [...data.teams].sort((a,b) => (b.roster.settings.wins||0)-(a.roster.settings.wins||0) || rosterScore(b.roster)-rosterScore(a.roster));
  $("standingsTable").classList.remove("empty-state");
  $("standingsTable").innerHTML = `<table class="data-table"><thead><tr><th>#</th><th>Team</th><th>W-L</th><th>PF</th></tr></thead><tbody>${sorted.map((t,i)=>`<tr class="${t.isMine?"mine":""}"><td>${i+1}</td><td>${escapeHtml(t.teamName)}${t.isMine?" ★":""}</td><td>${t.roster.settings.wins||0}-${t.roster.settings.losses||0}</td><td>${fmt(rosterScore(t.roster))}</td></tr>`).join("")}</tbody></table>`;
  $("leagueLeaders").classList.remove("empty-state");
  $("leagueLeaders").innerHTML = sorted.slice(0,5).map((t,i)=>`<div class="leader-row"><span class="rank">#${i+1}</span><div><div class="player-name">${escapeHtml(t.teamName)}</div><div class="player-meta">${t.roster.settings.wins||0}-${t.roster.settings.losses||0} record</div></div><strong>${fmt(rosterScore(t.roster))}</strong></div>`).join("");
  $("allTeams").classList.remove("empty-state");
  $("allTeams").innerHTML = data.teams.map(t=>`<button class="team-card ${t.isMine?"mine":""} ${selectedRosterId===t.roster.roster_id?"selected":""}" data-roster="${t.roster.roster_id}"><strong>${escapeHtml(t.teamName)}${t.isMine?" ★":""}</strong><span>${t.roster.settings.wins||0}-${t.roster.settings.losses||0} · ${fmt(rosterScore(t.roster))} PF</span></button>`).join("");
  document.querySelectorAll("[data-roster]").forEach(btn=>btn.addEventListener("click",()=>{
    selectedRosterId = Number(btn.dataset.roster);
    const team = data.teams.find(t=>t.roster.roster_id===selectedRosterId);
    $("selectedTeamRoster").innerHTML = `<div class="panel-heading" style="margin-top:22px"><h2>${escapeHtml(team.teamName)} roster</h2><span class="muted">${team.players.length} players</span></div><div class="player-list">${team.players.map(p=>playerRow(p,(team.roster.starters||[]).includes(p.id))).join("")}</div>`;
    renderAll(data);
  }));
}
async function connectLeague(id) {
  const config = leagues.find(l=>l.id===id);
  if (!config) return;
  activeLeagueId = id; renderSelect(); setConnected(false, "Connecting…");
  $("teamHeading").textContent = "Loading your league…";
  try {
    const [league, rosters, users, directory] = await Promise.all([
      getJson(leagueUrl(id, "")),
      getJson(leagueUrl(id, "rosters")),
      getJson(leagueUrl(id, "users")),
      getPlayerDirectory()
    ]);
    const userMap = Object.fromEntries(users.map(u=>[u.user_id,u]));
    const teams = rosters.map(roster=>{
      const user = userMap[roster.owner_id];
      const teamName = user?.metadata?.team_name || user?.display_name || `Roster ${roster.roster_id}`;
      return {
        roster, teamName,
        isMine: teamName.trim().toLowerCase() === (config.myTeam || "RunCMC").trim().toLowerCase(),
        players: (roster.players || []).map(pid=>playerInfo(pid,directory))
      };
    });
    activeData = {config, league, rosters, users, teams};
    renderAll(activeData);
    setConnected(true, "Sleeper connected");
    toast(`Loaded ${teams.length} teams from ${league.name || config.label}.`);
  } catch (error) {
    console.error(error);
    setConnected(false, "Connection failed");
    $("teamHeading").textContent = "Couldn't connect to Sleeper";
    $("leagueSubheading").textContent = error.message + ". Check the league ID and internet connection.";
    toast("Sleeper connection failed. Try refreshing.");
  }
}
function addLeague(id, type) {
  if (!/^\d+$/.test(id)) { toast("Enter a valid numeric Sleeper league ID."); return; }
  if (!leagues.some(l=>l.id===id)) leagues.push({id,type,label:`Sleeper ${id}`,myTeam:"RunCMC"});
  else leagues = leagues.map(l=>l.id===id?{...l,type}:l);
  saveLeagues(); activeLeagueId=id; renderSelect(); connectLeague(id);
}
document.querySelectorAll(".tab").forEach(btn=>btn.addEventListener("click",()=>showTab(btn.dataset.tab)));
$("leagueSelect").addEventListener("change",e=>connectLeague(e.target.value));
$("refreshBtn").addEventListener("click",()=>connectLeague(activeLeagueId));
$("addLeagueBtn").addEventListener("click",()=>$("addLeagueDialog").showModal());
$("settingsBtn").addEventListener("click",()=>$("settingsDialog").showModal());
document.querySelectorAll(".close-dialog").forEach(btn=>btn.addEventListener("click",()=>btn.closest("dialog").close()));
$("addLeagueForm").addEventListener("submit",e=>{
  e.preventDefault();
  const id=$("leagueIdInput").value.trim(), type=$("leagueTypeInput").value;
  $("addLeagueDialog").close(); $("leagueIdInput").value="";
  addLeague(id,type);
});
$("clearLeaguesBtn").addEventListener("click",()=>{
  leagues=[]; localStorage.removeItem(STORE_KEY); activeLeagueId=""; activeData=null;
  renderSelect(); setConnected(false,"Not connected");
  $("teamHeading").textContent="Welcome to Fantasy HQ";
  $("leagueSubheading").textContent="Connect a Sleeper league to get started.";
  ["recordStat","pointsStat","teamsStat","rosterStat"].forEach(id=>$(id).textContent="—");
  $("settingsDialog").close(); toast("Saved leagues removed from this device.");
});
renderSelect();
if (activeLeagueId) connectLeague(activeLeagueId);
