# Fantasy HQ — starter project

A mobile-friendly Sleeper league dashboard starter. It uses Sleeper's public read-only API and does not request a Sleeper password.

## Included
- Dark navy / electric-blue responsive dashboard
- Default league: Deuce Deuce (`1381307935468032000`)
- Default team selector: RunCMC
- Multiple Sleeper leagues can be added
- Redraft and dynasty league labels
- Roster, standings, and all-team views
- Sleeper NFL player directory lookup, cached in the browser for 24 hours
- Basic installable-web-app manifest and service worker

## Run locally
The app uses browser `fetch`, so run it from a local web server rather than opening `index.html` directly.

With Python installed:
```bash
python -m http.server 8000
```
Then visit `http://localhost:8000`.

Or use VS Code's Live Server extension.

## Publish later
1. Create a GitHub repository.
2. Upload the contents of this folder (not the ZIP itself).
3. Import the repository into Vercel.
4. Deploy with the default static settings.
5. Open the deployed URL on iPhone Safari → Share → Add to Home Screen.

## Important notes
- This is a starter project, not a finished commercial product.
- Sleeper API availability and browser CORS behavior should be tested in the deployed environment.
- The player directory is large. It is cached in localStorage for 24 hours; browser storage limits may prevent caching the full directory. If so, the app still uses the in-memory directory for the current session. A production version should move player data caching to IndexedDB or a small backend cache.
- The app currently displays basic team totals and roster details. It does not yet implement player projections, trade valuations, waiver recommendations, lineup optimization, or authenticated account actions.
- Sleeper scoring settings are not yet used to calculate custom player fantasy values.
